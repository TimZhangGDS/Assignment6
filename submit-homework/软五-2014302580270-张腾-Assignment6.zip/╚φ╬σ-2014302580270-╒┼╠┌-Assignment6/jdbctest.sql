/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50022
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50022
File Encoding         : 65001

Date: 2013-08-05 21:39:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `jdbctest`
-- ----------------------------
DROP TABLE IF EXISTS `jdbctest`;
CREATE TABLE `jdbctest` (
  `id` int(10) NOT NULL auto_increment,
  `username` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  `realName` varchar(10) default NULL,
  `sex` char(1) default NULL,
  `phone` varchar(20) default NULL,
  `email` varchar(30) default NULL,
  `vocation` varchar(10) default NULL,
  `city` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jdbctest
-- ----------------------------
INSERT INTO `jdbctest` VALUES ('13', '5544', '55', '', '', '', '', '', '');
INSERT INTO `jdbctest` VALUES ('14', '55', '55', '', '', '', '', '', '');
INSERT INTO `jdbctest` VALUES ('15', '888', '888', '', '', '', '', '', '');
INSERT INTO `jdbctest` VALUES ('16', '999', '999', '', '', '', '', '', '');
INSERT INTO `jdbctest` VALUES ('17', '555', '555', '555', '男', '', '555', '55', '');
INSERT INTO `jdbctest` VALUES ('18', '65', '65', '', '', '', '', '', '');
INSERT INTO `jdbctest` VALUES ('19', '二恶', '666', '如果是刚', '女', '3452354243245', '346363', '学生', '武汉');
INSERT INTO `jdbctest` VALUES ('20', 'eclipse', '666', '是官方说法', '男', '3452354243245', '3242', '学生', '武汉');
INSERT INTO `jdbctest` VALUES ('21', 'wetaf', '555', '是官方说法', '男', '345235', '3242', '学生', '武汉');
INSERT INTO `jdbctest` VALUES ('22', 'ywer', '66', 'er', '男', 's', 'er', 'rt', 'rt');
