package zt;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

public class DataBase2014302580270 {
	Connection connection;
	Statement statement;
	PreparedStatement pStatement;
	ResultSet rSet;
	/** ����һ�����ض����ݿ������ */
	public Connection getConnection() {
		try {
			//���������ļ�����ȡ���ݿ�����������Ϣ
			Properties pro = new Properties();
			try {
				pro.load(DataBase2014302580270.class.getResourceAsStream("/db.properties"));
			} catch (IOException e) {
				System.out.println("δ�ҵ������ļ�������");
			}
			String url = pro.getProperty("url");
			String user = pro.getProperty("user");
			String password = pro.getProperty("password");
			connection = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	/** �رղ��ͷ���Դ */
	public void close(){
		try {
			if(statement!=null){
				statement.close();
				statement = null;
			}
			if(pStatement!=null){
				pStatement.close();
				pStatement = null;
			}
			if(connection!=null){
				connection.close();
				connection = null;
			}
		} catch (Exception e) {
			System.out.println("���ݿ�close�쳣");
		}
	}



	
	/** PreparedStatement Ԥ����֮��ѯ��չ�� */
	public ArrayList<HashMap<Object, Object>> Query(String sql,Object[] s) {
		ArrayList<HashMap<Object, Object>> list = null;
		getConnection();
		try {
			pStatement = connection.prepareStatement(sql);
			for (int i = 0; i < s.length; i++) {
				pStatement.setObject(i+1, s[i]);
			}
			rSet = pStatement.executeQuery();
			list = ResultSetToList(rSet);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	/** ��ѯ�����ؼ�¼�� */
	public ResultSet getResultSet(String sql, Object[] objArr){
		getConnection();
		try {
			pStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			if(objArr!=null && objArr.length>0) {
				for (int i = 0; i < objArr.length; i++) {
					pStatement.setObject(i+1, objArr[i]);
				}
			}
			rSet = pStatement.executeQuery();
			//list = resultSetToList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//close();
		}
		return rSet;
	}
	
	/** �ѽ����ת��Object[][] */
	public Object[][] resultSetToObjectArray(ResultSet rs) {
		Object[][] data = null;
		try {	
			rs.last();
			int rows = rs.getRow();
			data = new Object[rows][];  
			ResultSetMetaData md = rs.getMetaData();//��ȡ��¼����Ԫ����
			int columnCount = md.getColumnCount();//����
			rs.first();
			int k = 0;
			while(rs.next()) {
				System.out.println("i"+k);
				Object[] row = new Object[columnCount];
				for(int i=0; i<columnCount; i++) {
					row[i] = rs.getObject(i+1).toString();
				}
				data[k] = row;
				k++;
			}
		} catch (Exception e) {
		}
		return data;
	}	
	
	/** ��Setת��ΪList */
	public ArrayList<HashMap<Object, Object>> ResultSetToList(ResultSet rSet) {
		ArrayList<HashMap<Object, Object>> list = null;
		try {
			list = new ArrayList<HashMap<Object, Object>>();
			HashMap<Object, Object> map = null;
			ResultSetMetaData mData = rSet.getMetaData();//��ȡ��¼����Ԫ����
			int num = mData.getColumnCount();//����
			while (rSet.next()) {
				map = new HashMap<Object, Object>(num);
				for (int i = 1; i <= num; i++) {
					map.put(mData.getColumnName(i), rSet.getObject(i));
				}
				list.add(map);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}

	/** ������������ִ��SQL��� */
	public int[] BatchSQL(String[] sqlArr) {
		int arr[] = null;
		getConnection();
		try {
			statement = connection.createStatement();
			if (sqlArr!=null && sqlArr.length>0) {
				for (int i = 0; i < sqlArr.length; i++) {
					statement.addBatch(sqlArr[i]);
				}
			}
			arr = statement.executeBatch();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close();
		}
		return arr;
	}
	
	/**��ArrayList<HashMap<Object, Object>>����������*/
	public void AllArray(ArrayList<HashMap<Object, Object>> list) {
		for (HashMap<Object, Object> maps : list) {
			Set<Object> keysObjects = maps.keySet();
			for(Object kObject : keysObjects){
				System.out.print(maps.get(kObject) + "\t");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		DataBase2014302580270 jDemo1 = new DataBase2014302580270();
		System.out.println(jDemo1.getConnection());
	}


}
