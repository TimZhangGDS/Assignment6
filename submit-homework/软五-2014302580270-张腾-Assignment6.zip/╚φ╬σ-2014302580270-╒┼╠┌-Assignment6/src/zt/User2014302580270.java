package zt;

import java.util.ArrayList;
import java.util.HashMap;

public class User2014302580270 extends DataBase2014302580270{
	
	/** ע�� */
	public boolean Reg(String[] arr){
		DataBase2014302580270 db = new DataBase2014302580270();
		String sql ="INSERT INTO jdbctest(username,password,realName,sex,phone,email,vocation,city) values(?,?,?,?,?,?,?,?);" ;

		return true;
	}
	
	/** ��֤�û���Ψһ�� */
	public boolean Unique(String nameString) {
		DataBase2014302580270 bDao = new DataBase2014302580270();
		String[] s = {nameString};
		ArrayList<HashMap<Object, Object>> list = bDao.Query("SELECT * FROM jdbctest WHERE username=?;",s);
		if (list.isEmpty()) {
			return true;
		}
		return false;
	}
	/** ��½  */
	public boolean login(String username, String password){
		DataBase2014302580270 bDao = new DataBase2014302580270();
		String[] s = {username ,password};
		ArrayList<HashMap<Object, Object>> list = bDao.Query("SELECT * FROM jdbctest WHERE username=? and password=?;",s);
		if (list.isEmpty()) {
			return false;
		}
		return true;
	}
	
	/** ��ʾ�����û�  */
	public ArrayList list(){
		ArrayList list = new ArrayList();
		return list;
	}

}
