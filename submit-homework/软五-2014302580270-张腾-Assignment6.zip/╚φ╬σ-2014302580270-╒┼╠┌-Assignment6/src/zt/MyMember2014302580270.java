package zt;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.*;

public class MyMember2014302580270 {

	public static TableModel Member() {
		String[][] playerInfo = new String[80][8];
		DataBase2014302580270 bDao = new DataBase2014302580270();
		String sql = "select id,realName,username,sex,phone,email,vocation,city from jdbctest";
		String[] ss = {};
		ArrayList<HashMap<Object, Object>> list = bDao.Query(sql, ss);
//		bDao.AllArray(list);
		int i = 0, j = 0;
		for (HashMap<Object, Object> maps : list) {
			Set<Object> keysObjects = maps.keySet();
			for (Object kObject : keysObjects) {
				playerInfo[i][j] = maps.get(kObject).toString();
				j++;
			}
			i++;
			j = 0;
		}
		String[] Names = { "id", "username", "sex", "phone","vocation","email","realName",   "city" };
		DefaultTableModel dModel = new DefaultTableModel(playerInfo, Names);
		return (TableModel)dModel;
	}

}